param(
    [Parameter(Mandatory = $true)]
    [string]$InstallDir
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$log = Join-Path $InstallDir 'formatch-instalacao.log'

function Write-InstallLog([string]$Message) {
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $log -Value "[$stamp] $Message" -Encoding UTF8
}

function Download-Official([string]$Url, [string]$Destination) {
    Write-InstallLog "Baixando $Url"
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination
}

function Resolve-Python311 {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        $resolved = & $launcher.Source -3.11 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $resolved) { return ([string]$resolved).Trim() }
    }
    $usualPath = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe'
    if (Test-Path $usualPath) { return $usualPath }
    return $null
}

function Install-BuildTools {
    $installer = Join-Path $env:TEMP 'vs_BuildTools_FORMATCH.exe'
    Download-Official 'https://aka.ms/vs/17/release/vs_BuildTools.exe' $installer
    Write-InstallLog 'Instalando Microsoft C++ Build Tools. Esta etapa pode demorar.'
    $arguments = @(
        '--quiet', '--wait', '--norestart', '--nocache',
        '--add', 'Microsoft.VisualStudio.Workload.VCTools',
        '--includeRecommended'
    )
    $process = Start-Process -FilePath $installer -ArgumentList $arguments -Verb RunAs -Wait -PassThru
    if ($process.ExitCode -notin @(0, 3010)) {
        throw "Microsoft C++ Build Tools retornou o código $($process.ExitCode)."
    }
}

try {
    Set-Content -Path $log -Value '' -Encoding UTF8
    Write-InstallLog 'Iniciando preparação do FORMATCH.'

    $basePython = Resolve-Python311
    if (-not $basePython) {
        $pythonInstaller = Join-Path $env:TEMP 'python-3.11.9-amd64.exe'
        Download-Official 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' $pythonInstaller
        Write-InstallLog 'Instalando Python 3.11 para o usuário atual.'
        $pythonProcess = Start-Process -FilePath $pythonInstaller -ArgumentList @(
            '/quiet', 'InstallAllUsers=0', 'PrependPath=1',
            'Include_launcher=1', 'InstallLauncherAllUsers=0',
            'Include_test=0', 'SimpleInstall=1'
        ) -Wait -PassThru
        if ($pythonProcess.ExitCode -ne 0) {
            throw "A instalação do Python retornou o código $($pythonProcess.ExitCode)."
        }
        $basePython = Resolve-Python311
        if (-not $basePython) { throw 'O Python foi instalado, mas não pôde ser localizado.' }
    }

    $vcRedist = Join-Path $env:TEMP 'VC_redist.x64_FORMATCH.exe'
    Download-Official 'https://aka.ms/vs/17/release/vc_redist.x64.exe' $vcRedist
    Write-InstallLog 'Instalando o Microsoft Visual C++ Runtime.'
    $vcProcess = Start-Process -FilePath $vcRedist -ArgumentList '/install', '/quiet', '/norestart' -Verb RunAs -Wait -PassThru
    if ($vcProcess.ExitCode -notin @(0, 1638, 3010)) {
        throw "O Visual C++ Runtime retornou o código $($vcProcess.ExitCode)."
    }

    $venv = Join-Path $InstallDir '.venv'
    $python = Join-Path $venv 'Scripts\python.exe'
    if (-not (Test-Path $python)) {
        Write-InstallLog 'Criando o ambiente isolado do FORMATCH.'
        & $basePython -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw 'Não foi possível criar o ambiente Python.' }
    }

    & $python -m pip install --upgrade pip setuptools wheel *>> $log
    Write-InstallLog 'Instalando bibliotecas do FORMATCH.'
    & $python -m pip install -e $InstallDir *>> $log
    if ($LASTEXITCODE -ne 0) {
        Write-InstallLog 'A instalação leve falhou; instalando ferramentas de compilação.'
        Install-BuildTools
        & $python -m pip install -e $InstallDir *>> $log
        if ($LASTEXITCODE -ne 0) {
            throw 'As bibliotecas não puderam ser instaladas mesmo após instalar o C++ Build Tools.'
        }
    }

    Write-InstallLog 'Instalação concluída com sucesso.'
    exit 0
} catch {
    Write-InstallLog ("ERRO: " + $_.Exception.Message)
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "Não foi possível concluir a instalação do FORMATCH.`n`nConsulte:`n$log",
        'Instalação do FORMATCH',
        'OK',
        'Error'
    ) | Out-Null
    exit 1
}
