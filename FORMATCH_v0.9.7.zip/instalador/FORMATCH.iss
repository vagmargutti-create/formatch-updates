#define MyAppName "FORMATCH"
#define MyAppVersion "0.9.7"
#define MyAppPublisher "FORMATCH"

[Setup]
AppId={{BDFB41F2-AD72-49C8-A663-C8AC8B2AB297}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\FORMATCH
DefaultGroupName=FORMATCH
OutputDir=..\dist_instalador
OutputBaseFilename=Instalar_FORMATCH
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
DisableProgramGroupPage=yes
UninstallDisplayName=FORMATCH

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Files]
Source: "..\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: ".venv\*,.git\*,.pytest_cache\*,__pycache__\*,*.pyc,tests\*,dist_instalador\*,formatch-atualizacao.log"

[Icons]
Name: "{autodesktop}\FORMATCH"; Filename: "{app}\iniciar.bat"; WorkingDir: "{app}"
Name: "{group}\FORMATCH"; Filename: "{app}\iniciar.bat"; WorkingDir: "{app}"

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\instalador\preparar_formatch.ps1"" -InstallDir ""{app}"""; StatusMsg: "Preparando o FORMATCH e instalando os componentes necessários..."; Flags: waituntilterminated
Filename: "{app}\iniciar.bat"; Description: "Abrir o FORMATCH"; WorkingDir: "{app}"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\.venv"
Type: files; Name: "{app}\formatch-instalacao.log"
Type: files; Name: "{app}\formatch-atualizacao.log"
