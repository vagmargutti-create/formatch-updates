@echo off
setlocal
cd /d "%~dp0"
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"

if not exist "%ISCC%" (
  echo Baixando o criador oficial do instalador...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $dest=Join-Path $env:TEMP 'innosetup-formatch.exe'; Invoke-WebRequest -UseBasicParsing 'https://github.com/jrsoftware/issrc/releases/download/is-6_7_3/innosetup-6.7.3.exe' -OutFile $dest; $bytes=[IO.File]::ReadAllBytes($dest); if($bytes.Length -lt 1000000 -or $bytes[0] -ne 77 -or $bytes[1] -ne 90){ throw 'O download nao e um executavel valido.' }; $signature=Get-AuthenticodeSignature $dest; if($signature.Status -ne 'Valid'){ throw 'A assinatura digital do criador nao e valida.' }"
  if errorlevel 1 goto :erro
  echo Instalando o criador do instalador...
  "%TEMP%\innosetup-formatch.exe" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART
  if errorlevel 1 goto :erro
)

if not exist "%ISCC%" goto :erro
echo Criando Instalar_FORMATCH.exe...
"%ISCC%" "instalador\FORMATCH.iss"
if errorlevel 1 goto :erro

echo.
echo PRONTO!
echo O instalador foi criado na pasta dist_instalador.
start "" "%~dp0dist_instalador"
pause
exit /b 0

:erro
echo.
echo Nao foi possivel gerar o instalador.
echo Verifique a internet e tente novamente.
pause
exit /b 1
